<?php
class DatabaseConfig {
    const DB_HOST = 'localhost';
    const DB_USER = 'root';
    const DB_PASS = '1234'; 
    const DB_NAME = 'ts_aqua'; // <-- Đổi tên DB thành cái này
}